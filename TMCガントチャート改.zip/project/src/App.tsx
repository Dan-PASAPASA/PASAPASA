import React, { useState } from 'react';
import { TaskList } from './components/TaskList';
import { AddTaskModal } from './components/AddTaskModal';
import { GanttChart } from './components/GanttChart';
import { DateRangeSelector } from './components/DateRangeSelector';
import { Task, AddTaskFormData } from './types';
import { exportToImage } from './utils/imageExport';
import { getInitialDateRange } from './utils/dateUtils';

function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState(getInitialDateRange());

  const handleAddTask = (taskData: AddTaskFormData) => {
    const newTask: Task = {
      id: Date.now().toString(),
      ...taskData,
    };
    setTasks([...tasks, newTask]);
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(tasks.filter(task => task.id !== taskId));
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">ガントチャート</h1>
            <div className="space-x-4">
              <button
                onClick={() => setIsModalOpen(true)}
                className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors"
              >
                ＋ タスクを追加
              </button>
              <button
                onClick={() => exportToImage('gantt-chart')}
                className="bg-purple-500 text-white px-4 py-2 rounded-md hover:bg-purple-600 transition-colors"
              >
                画像でダウンロード
              </button>
            </div>
          </div>

          <div className="mb-6">
            <DateRangeSelector
              startDate={dateRange.startDate}
              endDate={dateRange.endDate}
              onStartDateChange={(date) => setDateRange(prev => ({ ...prev, startDate: date }))}
              onEndDateChange={(date) => setDateRange(prev => ({ ...prev, endDate: date }))}
            />
          </div>

          <div className="space-y-8">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h2 className="text-lg font-semibold mb-4">ガントチャート表示</h2>
              <GanttChart
                tasks={tasks}
                viewStartDate={dateRange.startDate}
                viewEndDate={dateRange.endDate}
              />
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h2 className="text-lg font-semibold mb-4">タスク一覧</h2>
              <TaskList tasks={tasks} onDeleteTask={handleDeleteTask} />
            </div>
          </div>
        </div>
      </div>

      <AddTaskModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleAddTask}
      />
    </div>
  );
}

export default App;
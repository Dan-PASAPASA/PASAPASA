import React from 'react';
import { Task } from '../types';
import { format, eachDayOfInterval, isSameDay, isWithinInterval, startOfDay, endOfDay } from 'date-fns';

interface GanttChartProps {
  tasks: Task[];
  viewStartDate: string;
  viewEndDate: string;
}

export const GanttChart: React.FC<GanttChartProps> = ({ tasks, viewStartDate, viewEndDate }) => {
  if (!tasks.length || !viewStartDate || !viewEndDate) return null;

  const dateRange = eachDayOfInterval({
    start: new Date(viewStartDate),
    end: new Date(viewEndDate),
  });

  return (
    <div className="overflow-x-auto">
      <div className="inline-block min-w-full" id="gantt-chart">
        <div className="grid" style={{ gridTemplateColumns: `200px repeat(${dateRange.length}, 40px)` }}>
          {/* ヘッダー */}
          <div className="contents">
            <div className="sticky left-0 bg-white z-10 p-2 font-semibold border-b border-r">
              タスク名
            </div>
            {dateRange.map((date) => (
              <div
                key={date.toISOString()}
                className="p-2 text-xs font-medium text-center border-b border-r"
              >
                {format(date, 'MM/dd')}
              </div>
            ))}
          </div>

          {/* タスク行 */}
          {tasks.map((task, taskIndex) => {
            const taskColors = [
              'bg-blue-500',
              'bg-purple-500',
              'bg-green-500',
              'bg-orange-500',
              'bg-pink-500'
            ];
            const colorIndex = taskIndex % taskColors.length;

            // タスクの期間を計算
            let barStartIndex = -1;
            let barLength = 0;

            dateRange.forEach((date, index) => {
              const currentDate = startOfDay(date);
              const taskStartDate = startOfDay(new Date(task.startDate));
              const taskEndDate = endOfDay(new Date(task.endDate));

              if (isSameDay(currentDate, taskStartDate)) {
                barStartIndex = index;
              }

              if (barStartIndex !== -1 && isWithinInterval(currentDate, {
                start: taskStartDate,
                end: taskEndDate,
              })) {
                barLength++;
              }
            });

            return (
              <div key={task.id} className="contents group">
                <div className="sticky left-0 bg-white z-10 p-2 border-b border-r truncate">
                  {task.name}
                </div>
                {dateRange.map((date, index) => {
                  const currentDate = startOfDay(date);
                  const taskStartDate = startOfDay(new Date(task.startDate));
                  const taskEndDate = endOfDay(new Date(task.endDate));

                  const isInRange = isWithinInterval(currentDate, {
                    start: taskStartDate,
                    end: taskEndDate,
                  });

                  const isStart = isSameDay(currentDate, taskStartDate);
                  const isEnd = isSameDay(currentDate, taskEndDate);

                  return (
                    <div
                      key={date.toISOString()}
                      className="relative p-2 border-b border-r"
                    >
                      {isInRange && (
                        <div
                          className={`
                            absolute inset-0 ${taskColors[colorIndex]}
                            ${isStart ? 'rounded-l-full' : ''}
                            ${isEnd ? 'rounded-r-full' : ''}
                          `}
                        >
                          {isStart && barLength >= 3 && (
                            <div className="absolute inset-0 flex items-center px-3 text-white text-sm whitespace-nowrap overflow-hidden">
                              {task.name}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};